import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutHComponent } from './ajout-h.component';

describe('AjoutHComponent', () => {
  let component: AjoutHComponent;
  let fixture: ComponentFixture<AjoutHComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AjoutHComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjoutHComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
