export class Commentaire {
    constructor(
    public nom:string,
    public message:string, 
   ){}
   }
   
