import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiComponent } from '../api/api.component';
import { FooterComponent } from '../footer/footer.component';
import { MenuComponent } from '../menu/menu.component';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [MenuComponent,FooterComponent,ApiComponent,RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  
}
