import { Component } from '@angular/core';
import { inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-api',
  standalone: true,
  imports: [],
  templateUrl: './api.component.html',
  styleUrl: './api.component.css'
})
export class ApiComponent implements OnInit{
  private readonly http:HttpClient=inject(HttpClient);
  dog:any
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.http.get('https://dog.ceo/api/breeds/image/random').subscribe(
      (data: any)=>{console.log(data)
      this.dog=data})
    }

}


