import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
@Component({
  selector: 'app-parfums',
  standalone: true,
  imports: [RouterLink,RouterOutlet],
  templateUrl: './parfums.component.html',
  styleUrl: './parfums.component.css'
})
export class ParfumsComponent {

}
